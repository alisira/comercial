package com.comercial;

import java.io.IOException;
import java.security.Principal;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.WebUtils;



//@EnableJpaRepositories
@SpringBootApplication
@RestController
public class UiApplication {



	 @RequestMapping("/resource")
	 public Map<String, Object> home() {
		 
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("id", UUID.randomUUID().toString());
		model.put("content", "Hello World");
		return model;
	 }

	 public static void main(String[] args) {
		 
		SpringApplication.run(UiApplication.class, args);
		
	 }

	 


	 @RequestMapping("/token")
	 public Map<String,String> token(HttpSession session, Principal user) {
		 System.out.println("token:" + session.getId());
		 //System.out.println(session.getAttributeNames());
		 //System.out.println("user en token:" + user.toString());
		 System.out.println(Collections.singletonMap("token", session.getId()));

		 return Collections.singletonMap("token", session.getId());
	 }


	
}
