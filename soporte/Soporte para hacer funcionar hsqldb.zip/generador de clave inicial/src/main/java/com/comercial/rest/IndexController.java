package com.comercial.rest;

import java.util.Iterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.comercial.domain.User;
import com.comercial.model.Users;
import com.comercial.service.UserService;

@Controller
public class IndexController {
	
	
	@Autowired
	private UserService userService;
	
	// inject via application.properties
	@Value("${welcome.message:test}")
	private String message;
	
	@RequestMapping("/")
	public String getIndexPage(){
		
		Users entity =  new Users();
		
		
		/*userService.deleteAll();
		entity.setEmail("alisirar@gmail.com");
		entity.setEnabled((short) 1);
		entity.setUserName("alfonso@founderlist.la");
		entity.setPassword("$2a$06$Jogkd6HnTLE61naCeuN9c.tHO2IcoCzveCQJAoRkbnFzGh8OkhQjC");		
		userService.save(entity);
		*/

		//select user0_.user_id as user_id1_3_, user0_.email as email2_3_, user0_.enabled as enabled3_3_, user0_.password as password4_3_, user0_.user_name as user_nam5_3_ from users user0_

		
		Iterable<Users> a = userService.findAll();
		
		Iterator<Users> it = a.iterator();
		 
		while (it.hasNext()) {
		
			Users nombre= it.next();		
			System.out.println(nombre);
		 
		}
		
		
		//System.out.println(a.toString());
		
		
		return "layout/backoffice";
	}
	
	
	/*Retornar un 
	@RequestMapping("/")
	public String welcome(Map<String, Object> model) {
		model.put("message", this.message);
		return "welcome";
	}
	*/
	
		
	
}
