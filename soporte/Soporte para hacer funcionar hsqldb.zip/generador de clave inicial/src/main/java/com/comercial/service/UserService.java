package com.comercial.service;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestParam;

import com.comercial.domain.User;
import com.comercial.domain.UserRepository;
import com.comercial.model.Users;


@Service("UserService")
@Transactional
public class UserService {
	
	@Autowired
	private UserRepository userRepository;

	
	public  UserRepository save(Users entity) {
		userRepository.save(entity);
		return userRepository;
	}

	public Iterable<Users> findAll() {

		Sort sort = null;
		
		//userRepository.fi

		return  userRepository.findAll( );


	}
	
	public long count() {		
		return userRepository.count();
	}
	
	public void deleteAll() {		
		userRepository.deleteAll();
	}
	

}

